from operator import add
import re

def fix_line(line):
	line = line.lower()
	line = re.sub(r"[^ a-zA-Z0-9]"," ",line)
	line = re.sub(r"[ ]{1,}"," ",line)
	line = line.strip(' \n')
	return line   

def map1bigram(sentence):
	sentence = fix_line(sentence)
	output = []
	words = sentence.split(' ')
	for i in range(len(words) - 1):
		output = output + [(words[i],words[i+1])]
	return output

def map1trigram(sentence):
	sentence = fix_line(sentence)
	output = []
	words = sentence.split(' ')
	for i in range(len(words) - 2):
		output = output + [(words[i],words[i+1], words[i+2])]
	return output

file = open('/home/adesh/Documents/bda/project/in.txt')
lines = file.read()
file.close()
sentencesRdd = sc.parallelize(lines.split('.'), 4)
a = sentencesRdd.collect()

bigramRdd = sentencesRdd.flatMap(map1bigram)
a = bigramRdd.collect()

# bigramRddWithFrequency = bigramRdd.map(lambda x: (x,1)).reduceByKey(add)
# bigramRddWithFrequency = bigramRddWithFrequency.sortByKey()

trigramRdd = sentencesRdd.flatMap(map1trigram)
trigramRdd = trigramRdd.map(lambda x: (x,1)).reduceByKey(add)

document_file = open('/home/adesh/Documents/bda/project/document.txt')
document = document_file.read()
documentRdd = sc.parallelize(document.split('.'),4)
documentRdd = documentRdd.flatMap(map1bigram)
print documentRdd.collect()

commonBigramsRdd = documentRdd.intersection(bigramRdd)
print commonBigramsRdd.collect()